
-- MyCharPanel Epic 9.9.5 - Azeroth Grimoire
-- World of Warcraft Retail
-- SavedVariables: MyCharPanelDB

local ADDON_NAME = ...
local MCP = CreateFrame("Frame", "MyCharPanelCore")
_G.MyCharPanel = MCP

local VERSION = "9.9.5"
local DB_NAME = "MyCharPanelDB"

-- =========================================================
-- THEMES
-- =========================================================

local GOLD = {0.67, 0.43, 0.17, 1}
local GOLD_BRIGHT = {0.88, 0.67, 0.32, 1}
local GOLD_DARK = {0.34, 0.23, 0.12, 1}

local DARK, PANEL, PANEL_HOVER, PANEL_INNER = {}, {}, {}, {}
local ARCANE, TEXT, MUTED = {}, {}, {}

local THEMES = {
    dark = {
        DARK = {0.075, 0.052, 0.033, 1},
        PANEL = {0.16, 0.112, 0.067, 1},
        PANEL_HOVER = {0.25, 0.175, 0.10, 1},
        PANEL_INNER = {0.105, 0.073, 0.043, 1},
        ARCANE = {0.42, 0.28, 0.14, 1},

        TEXT = {1.00, 0.97, 0.90, 1},
        MUTED = {0.91, 0.86, 0.76, 1},

        GOLD = {0.72, 0.48, 0.20, 1},
        GOLD_BRIGHT = {1.00, 0.79, 0.43, 1},
        GOLD_DARK = {0.38, 0.25, 0.12, 1},
    },

    light = {
        DARK = {0.80, 0.69, 0.51, 1},
        PANEL = {0.94, 0.85, 0.68, 1},
        PANEL_HOVER = {1.00, 0.93, 0.78, 1},
        PANEL_INNER = {0.87, 0.77, 0.58, 1},
        ARCANE = {0.49, 0.32, 0.16, 1},

        TEXT = {0.08, 0.045, 0.02, 1},
        MUTED = {0.20, 0.13, 0.065, 1},

        GOLD = {0.43, 0.26, 0.085, 1},
        GOLD_BRIGHT = {0.49, 0.29, 0.075, 1},
        GOLD_DARK = {0.34, 0.21, 0.075, 1},
    },
}

local function CopyColor(target, source)
    target[1], target[2], target[3] = source[1], source[2], source[3]
    target[4] = source[4] or 1
end

local function ApplyThemeColors()
    local db = _G[DB_NAME]
    local themeName = db and db.settings and db.settings.theme or "dark"
    local theme = THEMES[themeName] or THEMES.dark

    CopyColor(DARK, theme.DARK)
    CopyColor(PANEL, theme.PANEL)
    CopyColor(PANEL_HOVER, theme.PANEL_HOVER)
    CopyColor(PANEL_INNER, theme.PANEL_INNER)
    CopyColor(ARCANE, theme.ARCANE)
    CopyColor(TEXT, theme.TEXT)
    CopyColor(MUTED, theme.MUTED)
    CopyColor(GOLD, theme.GOLD)
    CopyColor(GOLD_BRIGHT, theme.GOLD_BRIGHT)
    CopyColor(GOLD_DARK, theme.GOLD_DARK)
end

local mainWindow, bagsWindow, bankWindow
local statsWindow, historyWindow, settingsWindow, minimapButton

local bagsReady = false
local bankOpen = false
local sessionStart
local sessionCharacterKey
local pendingTimePlayed = false

-- Forward declarations
local FillStorage

-- =========================================================
-- DATABASE
-- =========================================================

local function GetDB()
    if not _G[DB_NAME] then
        _G[DB_NAME] = {}
    end

    local db = _G[DB_NAME]
    db.characters = db.characters or {}
    db.settings = db.settings or {}

    local s = db.settings

    if s.showMinimap == nil then s.showMinimap = true end
    if s.showHistory == nil then s.showHistory = true end
    if s.showStats == nil then s.showStats = true end
    if s.showGlow == nil then s.showGlow = true end
    if s.showDecorations == nil then s.showDecorations = true end

    -- Прозрачность отключена: окна всегда полностью непрозрачные.
    s.opacity = nil

    s.scale = tonumber(s.scale) or 1
    s.scale = math.max(0.75, math.min(1.25, s.scale))

    s.historyLimit = tonumber(s.historyLimit) or 500

    if s.theme ~= "dark" and s.theme ~= "light" then
        s.theme = "dark"
    end

    if s.bagsView ~= "grid" and s.bagsView ~= "list" then
        s.bagsView = "grid"
    end

    if s.bankView ~= "grid" and s.bankView ~= "list" then
        s.bankView = "grid"
    end

    ApplyThemeColors()
    return db
end

local function Print(message)
    DEFAULT_CHAT_FRAME:AddMessage(
        "|cffffc45cMyCharPanel:|r " .. tostring(message)
    )
end

local function GetCharacterKey()
    return (UnitName("player") or "Unknown")
        .. "-" .. (GetRealmName() or "Unknown Realm")
end

local function GetClassInfo()
    local name, class = UnitClass("player")
    return name or "Unknown", class or "UNKNOWN"
end

-- =========================================================
-- SPECIALIZATION
-- =========================================================

local function GetSpecializationName()
    if not GetSpecialization or not GetSpecializationInfo then
        return nil
    end

    local specIndex = GetSpecialization()

    if not specIndex then
        return nil
    end

    local success, specID, name = pcall(
        GetSpecializationInfo,
        specIndex
    )

    if success and name and name ~= "" then
        return name
    end

    return nil
end

local function GetEquippedItemLevel()
    if not GetAverageItemLevel then return nil end

    local success, average, equipped = pcall(GetAverageItemLevel)
    if not success then return nil end

    -- The second return value is the equipped average. Fall back to the
    -- first value only when the equipped value is unavailable or invalid.
    local itemLevel = tonumber(equipped)
    if not itemLevel or itemLevel <= 0 then
        itemLevel = tonumber(average)
    end

    if not itemLevel or itemLevel <= 0 then
        return nil
    end

    return itemLevel
end

local function GetProfessionsSafe()
    local result = {}

    if not GetProfessions or not GetProfessionInfo then
        return result
    end

    local professions = {GetProfessions()}

    for _, index in ipairs(professions) do
        if index then
            local name, icon, skill, maximum = GetProfessionInfo(index)

            if name then
                result[#result + 1] = {
                    name = name,
                    icon = icon,
                    skill = skill or 0,
                    maxSkill = maximum or 0,
                }
            end
        end
    end

    return result
end

local function GetCharacterInfo()
    local className, class = GetClassInfo()

    return {
        key = GetCharacterKey(),
        name = UnitName("player") or "Unknown",
        realm = GetRealmName() or "Unknown Realm",
        class = class,
        className = className,
        race = UnitRace("player") or "Unknown",
        level = UnitLevel("player") or 1,
        faction = UnitFactionGroup("player") or "Unknown",
        guild = GetGuildInfo("player") or "",
        spec = GetSpecializationName(),
        itemLevel = GetEquippedItemLevel(),
        professions = GetProfessionsSafe(),
        money = GetMoney() or 0,
        updated = date("%Y-%m-%d %H:%M:%S"),
        updatedTimestamp = time(),
    }
end

local function FormatMoney(amount)
    amount = tonumber(amount) or 0

    local gold = math.floor(amount / 10000)
    local silver = math.floor((amount % 10000) / 100)
    local copper = amount % 100

    return string.format(
        "%d |cffffd700з|r %02d |cffc7c7cfс|r %02d |cffeda55fм|r",
        gold, silver, copper
    )
end

local function FormatPlayedTime(seconds)
    seconds = tonumber(seconds) or 0

    local days = math.floor(seconds / 86400)
    local hours = math.floor((seconds % 86400) / 3600)
    local minutes = math.floor((seconds % 3600) / 60)

    if days > 0 then
        return string.format("%dд %dч %dм", days, hours, minutes)
    elseif hours > 0 then
        return string.format("%dч %dм", hours, minutes)
    end

    return string.format("%dм", minutes)
end

local function GetItemName(itemID)
    if not itemID then return "Неизвестный предмет" end
    return GetItemInfo(itemID) or ("Предмет #" .. tostring(itemID))
end

local function GetClassColor(class)
    if C_ClassColor and C_ClassColor.GetClassColor then
        local color = C_ClassColor.GetClassColor(class)

        if color then
            return color.r, color.g, color.b
        end
    end

    return 1, 1, 1
end

local function GetLocalizedFaction(faction)
    if not faction then
        return "Неизвестно"
    end

    faction = tostring(faction)

    if faction == "Alliance" or faction == "Альянс" then
        return FACTION_ALLIANCE or "Альянс"

    elseif faction == "Horde" or faction == "Орда" then
        return FACTION_HORDE or "Орда"

    elseif faction == "Neutral" or faction == "Нейтральная" then
        return "Нейтральная"
    end

    return faction
end

-- Отдельная правильная иконка для каждой фракции.
local function GetFactionIcon(faction)
    faction = tostring(faction or "")

    if faction == "Horde" or faction == "Орда" then
        return "Interface/Icons/Achievement_PVP_H_01"

    elseif faction == "Alliance" or faction == "Альянс" then
        return "Interface/Icons/Achievement_PVP_A_01"
    end

    return "Interface/Icons/INV_Misc_QuestionMark"
end

-- =========================================================
-- THEME REFRESH
-- =========================================================

local function RefreshFrameTheme(frame)
    if not frame then return end

    if frame.mcpBackground and frame.SetBackdropColor then
        local c = frame.mcpBackground

        frame:SetBackdropColor(
            c[1], c[2], c[3], c[4] or 1
        )
    end

    if frame.mcpBorder and frame.SetBackdropBorderColor then
        local c = frame.mcpBorder

        frame:SetBackdropBorderColor(
            c[1], c[2], c[3], c[4] or 1
        )
    end

    for _, region in ipairs({frame:GetRegions()}) do
        if region.mcpTextColor and region.SetTextColor then
            local c = region.mcpTextColor

            region:SetTextColor(
                c[1], c[2], c[3], c[4] or 1
            )
        end
    end

    for _, child in ipairs({frame:GetChildren()}) do
        RefreshFrameTheme(child)
    end
end

local function RefreshAllThemes()
    ApplyThemeColors()

    local windows = {
        mainWindow, bagsWindow, bankWindow,
        statsWindow, historyWindow, settingsWindow,
    }

    for _, window in pairs(windows) do
        if window then
            RefreshFrameTheme(window)
        end
    end

    if mainWindow and mainWindow:IsShown() then
        MCP:Refresh()

        if MCP.selectedCharacter then
            MCP:ShowDetails(MCP.selectedCharacter)
        end
    end

    if bagsWindow and bagsWindow:IsShown()
        and bagsWindow.characterKey then
        FillStorage(bagsWindow, bagsWindow.characterKey)
    end

    if bankWindow and bankWindow:IsShown()
        and bankWindow.characterKey then
        FillStorage(bankWindow, bankWindow.characterKey)
    end
end

-- =========================================================
-- VISUAL SETTINGS
-- =========================================================

local function ApplyWindowSettings()
    local settings = GetDB().settings
    local scale = settings.scale

    local windows = {
        mainWindow, bagsWindow, bankWindow,
        statsWindow, historyWindow, settingsWindow,
    }

    for _, window in pairs(windows) do
        if window then
            window:SetAlpha(1)
            window:SetScale(scale)
        end
    end
end

local function ApplyGlowSettings()
    local enabled = GetDB().settings.showGlow

    local windows = {
        mainWindow, bagsWindow, bankWindow,
        statsWindow, historyWindow, settingsWindow,
    }

    for _, window in pairs(windows) do
        if window and window.edgeGlow then
            for _, texture in ipairs(window.edgeGlow) do
                texture:SetShown(enabled)
            end
        end

        if window then
            for _, child in ipairs({window:GetChildren()}) do
                if child.edgeGlow then
                    for _, texture in ipairs(child.edgeGlow) do
                        texture:SetShown(enabled)
                    end
                end
            end
        end
    end

    if minimapButton and minimapButton.edgeGlow then
        for _, texture in ipairs(minimapButton.edgeGlow) do
            texture:SetShown(enabled)
        end
    end
end

local function ApplyDecorationSettings()
    local enabled = GetDB().settings.showDecorations

    local windows = {
        mainWindow, bagsWindow, bankWindow,
        statsWindow, historyWindow, settingsWindow,
    }

    for _, window in pairs(windows) do
        if window and window.cornerAccents then
            for _, texture in ipairs(window.cornerAccents) do
                texture:SetShown(enabled)
            end
        end
    end
end

-- =========================================================
-- DECORATION AND UI HELPERS
-- =========================================================

local function CreateBackdrop(frame, background, border)
    if not frame.SetBackdrop then return end

    frame:SetBackdrop({
        bgFile = "Interface/Buttons/WHITE8X8",
        edgeFile = "Interface/Buttons/WHITE8X8",
        edgeSize = 2,
        insets = {
            left = 2,
            right = 2,
            top = 2,
            bottom = 2,
        },
    })

    frame.mcpBackground = background
    frame.mcpBorder = border

    frame:SetBackdropColor(
        background[1], background[2],
        background[3], background[4] or 1
    )

    frame:SetBackdropBorderColor(
        border[1], border[2],
        border[3], border[4] or 1
    )
end

local function AddEdgeGlow(frame, intensity)
    if not frame or frame.edgeGlow then return end

    intensity = intensity or 0.35
    local edges = {}

    local function MakeEdge()
        local texture = frame:CreateTexture(nil, "OVERLAY")

        texture:SetTexture("Interface/Buttons/WHITE8X8")
        texture:SetBlendMode("ADD")

        texture:SetVertexColor(
            GOLD_BRIGHT[1], GOLD_BRIGHT[2],
            GOLD_BRIGHT[3], intensity
        )

        edges[#edges + 1] = texture
        return texture
    end

    local top = MakeEdge()
    top:SetPoint("TOPLEFT", frame, "TOPLEFT", 3, -2)
    top:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -3, -2)
    top:SetHeight(2)

    local bottom = MakeEdge()
    bottom:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 3, 2)
    bottom:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -3, 2)
    bottom:SetHeight(2)

    local left = MakeEdge()
    left:SetPoint("TOPLEFT", frame, "TOPLEFT", 2, -3)
    left:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 2, 3)
    left:SetWidth(2)

    local right = MakeEdge()
    right:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -2, -3)
    right:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -2, 3)
    right:SetWidth(2)

    frame.edgeGlow = edges

    for _, texture in ipairs(edges) do
        texture:SetShown(GetDB().settings.showGlow)
    end
end

local function AddCornerAccents(frame)
    local accents = {}

    local positions = {
        {"TOPLEFT", 5, -5},
        {"TOPRIGHT", -5, -5},
        {"BOTTOMLEFT", 5, 5},
        {"BOTTOMRIGHT", -5, 5},
    }

    for _, position in ipairs(positions) do
        local texture = frame:CreateTexture(nil, "OVERLAY")

        texture:SetTexture("Interface/Buttons/WHITE8X8")

        texture:SetVertexColor(
            GOLD_BRIGHT[1], GOLD_BRIGHT[2],
            GOLD_BRIGHT[3], 0.85
        )

        texture:SetSize(7, 7)

        texture:SetPoint(
            position[1], frame, position[1],
            position[2], position[3]
        )

        accents[#accents + 1] = texture
    end

    frame.cornerAccents = accents

    for _, texture in ipairs(accents) do
        texture:SetShown(GetDB().settings.showDecorations)
    end
end

local function AddInnerFrame(frame, inset, color)
    local inner = CreateFrame(
        "Frame", nil, frame, "BackdropTemplate"
    )

    inner:SetPoint("TOPLEFT", inset, -inset)
    inner:SetPoint("BOTTOMRIGHT", -inset, inset)
    inner:SetFrameLevel(frame:GetFrameLevel() + 1)

    CreateBackdrop(inner, PANEL_INNER, color or GOLD_DARK)

    return inner
end

local function AddArcaneDivider(parent, y, width)
    local darkLine = parent:CreateTexture(nil, "ARTWORK")

    darkLine:SetTexture("Interface/Buttons/WHITE8X8")
    darkLine:SetVertexColor(
        ARCANE[1], ARCANE[2], ARCANE[3], 0.8
    )

    darkLine:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, -y)
    darkLine:SetSize(width, 3)

    local goldLine = parent:CreateTexture(nil, "OVERLAY")

    goldLine:SetTexture("Interface/Buttons/WHITE8X8")
    goldLine:SetVertexColor(
        GOLD[1], GOLD[2], GOLD[3], 0.7
    )

    goldLine:SetPoint("TOPLEFT", darkLine, "TOPLEFT", 0, -1)
    goldLine:SetSize(width, 1)
end

local function CreateText(parent, value, size, color)
    local fs = parent:CreateFontString(
        nil, "OVERLAY", "GameFontNormal"
    )

    fs:SetFont(STANDARD_TEXT_FONT, size or 12, "")
    fs:SetText(value or "")
    fs:SetJustifyH("LEFT")

    color = color or TEXT
    fs.mcpTextColor = color

    fs:SetTextColor(
        color[1], color[2], color[3], color[4] or 1
    )

    return fs
end

local function CreateButton(parent, value, width, height, callback)
    local button = CreateFrame(
        "Button", nil, parent, "BackdropTemplate"
    )

    button:SetSize(width or 130, height or 28)

    CreateBackdrop(button, PANEL_INNER, GOLD_DARK)
    AddEdgeGlow(button, 0.18)

    button.label = CreateText(button, value, 11, TEXT)
    button.label:SetPoint("CENTER")

    button:SetScript("OnClick", function()
        if callback then
            callback()
        end
    end)

    button:SetScript("OnEnter", function(self)
        self:SetBackdropColor(
            PANEL_HOVER[1], PANEL_HOVER[2],
            PANEL_HOVER[3], PANEL_HOVER[4]
        )

        self:SetBackdropBorderColor(
            GOLD_BRIGHT[1], GOLD_BRIGHT[2],
            GOLD_BRIGHT[3], 1
        )

        self.label:SetTextColor(
            GOLD_BRIGHT[1], GOLD_BRIGHT[2], GOLD_BRIGHT[3]
        )
    end)

    button:SetScript("OnLeave", function(self)
        self:SetBackdropColor(
            PANEL_INNER[1], PANEL_INNER[2],
            PANEL_INNER[3], PANEL_INNER[4]
        )

        self:SetBackdropBorderColor(
            GOLD_DARK[1], GOLD_DARK[2],
            GOLD_DARK[3], GOLD_DARK[4]
        )

        self.label:SetTextColor(
            TEXT[1], TEXT[2], TEXT[3]
        )
    end)

    return button
end

local function CreateWindow(name, width, height, title)
    local frame = CreateFrame(
        "Frame", name, UIParent, "BackdropTemplate"
    )

    frame:SetSize(width, height)
    frame:SetPoint("CENTER")
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")

    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)

    frame:SetFrameStrata("FULLSCREEN_DIALOG")
    frame:SetToplevel(true)

    CreateBackdrop(frame, DARK, GOLD)
    AddInnerFrame(frame, 5, GOLD_DARK)
    AddCornerAccents(frame)
    AddEdgeGlow(frame, 0.35)

    local header = CreateFrame(
        "Frame", nil, frame, "BackdropTemplate"
    )

    header:SetPoint("TOPLEFT", 9, -9)
    header:SetPoint("TOPRIGHT", -9, -9)
    header:SetHeight(42)

    CreateBackdrop(header, PANEL, ARCANE)

    local heading = CreateText(
        header, title, 16, GOLD_BRIGHT
    )

    heading:SetPoint("LEFT", 12, 0)

    local headerLine = header:CreateTexture(nil, "ARTWORK")

    headerLine:SetTexture("Interface/Buttons/WHITE8X8")
    headerLine:SetVertexColor(
        GOLD[1], GOLD[2], GOLD[3], 0.8
    )

    headerLine:SetPoint("BOTTOMLEFT", 5, 0)
    headerLine:SetPoint("BOTTOMRIGHT", -5, 0)
    headerLine:SetHeight(1)

    local close = CreateButton(frame, "X", 27, 24, function()
        frame:Hide()
    end)

    close:SetPoint("TOPRIGHT", -14, -17)

    if not tContains(UISpecialFrames, name) then
        tinsert(UISpecialFrames, name)
    end

    frame:Hide()
    frame:SetAlpha(1)
    frame:SetScale(GetDB().settings.scale)

    return frame
end

local function ClearFrame(frame)
    if not frame then return end

    for _, child in ipairs({frame:GetChildren()}) do
        child:Hide()
        child:SetParent(nil)
    end

    for _, region in ipairs({frame:GetRegions()}) do
        region:Hide()
        region:SetParent(nil)
    end
end

local function AddLine(parent, value, y, color)
    local fs = CreateText(parent, value, 12, color or TEXT)

    fs:SetPoint("TOPLEFT", 0, -y)
    fs:SetWidth(450)

    return fs
end

local function AddIconLine(parent, icon, value, y, color)
    local texture = parent:CreateTexture(nil, "ARTWORK")

    texture:SetSize(15, 15)
    texture:SetPoint("TOPLEFT", 1, -y - 1)
    texture:SetTexture(icon or 134400)

    local fs = CreateText(parent, value, 12, color or TEXT)

    fs:SetPoint("LEFT", texture, "RIGHT", 7, 0)
    fs:SetWidth(425)

    return fs
end

-- =========================================================
-- CLASS ICONS
-- =========================================================

local CLASS_ICON_TEXTURE =
    "Interface/GLUES/CHARACTERCREATE/UI-CHARACTERCREATE-CLASSES"

local function SetClassIcon(texture, class)
    if not texture then return end

    local coords = CLASS_ICON_TCOORDS
        and CLASS_ICON_TCOORDS[class]

    if coords then
        texture:SetTexture(CLASS_ICON_TEXTURE)

        texture:SetTexCoord(
            coords[1], coords[2],
            coords[3], coords[4]
        )
    else
        texture:SetTexture(
            "Interface/Icons/INV_Misc_QuestionMark"
        )

        texture:SetTexCoord(
            0.08, 0.92, 0.08, 0.92
        )
    end
end

-- =========================================================
-- BAGS AND BANK SNAPSHOTS
-- =========================================================

local function GetContainerSnapshot(bagID)
    local result = {}

    if not C_Container then
        return result
    end

    local slots = C_Container.GetContainerNumSlots(bagID) or 0

    for slot = 1, slots do
        local info = C_Container.GetContainerItemInfo(
            bagID, slot
        )

        if info then
            result[#result + 1] = {
                id = info.itemID,
                name = GetItemName(info.itemID),
                count = info.stackCount or 1,
                quality = info.quality or 0,
                slot = slot,
                bag = bagID,
                icon = info.iconFileID,
            }
        end
    end

    return result
end

local function AreBagsLoaded()
    return C_Container
        and C_Container.GetContainerNumSlots
        and (
            C_Container.GetContainerNumSlots(
                BACKPACK_CONTAINER
            ) or 0
        ) > 0
end

local function SnapshotBags()
    local result = {}

    for bagID = BACKPACK_CONTAINER,
        NUM_TOTAL_EQUIPPED_BAG_SLOTS do

        for _, item in ipairs(GetContainerSnapshot(bagID)) do
            result[#result + 1] = item
        end
    end

    return result
end

local function SnapshotBank()
    local result = {}
    local loaded = false

    if not C_Container then
        return result, false
    end

    local function AddBag(bagID)
        local slots = C_Container.GetContainerNumSlots(bagID) or 0

        if slots > 0 then
            loaded = true
        end

        for _, item in ipairs(GetContainerSnapshot(bagID)) do
            result[#result + 1] = item
        end
    end

    AddBag(BANK_CONTAINER)

    if NUM_BANKBAGSLOTS then
        for bagID = NUM_TOTAL_EQUIPPED_BAG_SLOTS + 1,
            NUM_TOTAL_EQUIPPED_BAG_SLOTS + NUM_BANKBAGSLOTS do

            AddBag(bagID)
        end
    end

    if REAGENTBANK_CONTAINER then
        AddBag(REAGENTBANK_CONTAINER)
    end

    return result, loaded
end

-- =========================================================
-- HISTORY AND CHARACTER SAVING
-- =========================================================

local function AddHistory(character, force)
    if not character then return end

    local db = GetDB()

    if not db.settings.showHistory then
        return
    end

    character.history = character.history or {}

    local now = time()
    local last = character.history[#character.history]

    local snapshot = {
        timestamp = now,
        date = date("%Y-%m-%d %H:%M:%S"),
        level = character.level or 1,
        money = character.money or 0,
        itemLevel = character.itemLevel or 0,
        spec = character.spec or "Unknown",
    }

    if last and not force then
        local changed =
            last.level ~= snapshot.level
            or last.money ~= snapshot.money
            or last.itemLevel ~= snapshot.itemLevel
            or last.spec ~= snapshot.spec

        if not changed and now - (last.timestamp or 0) < 21600 then
            return
        end
    end

    character.history[#character.history + 1] = snapshot

    while #character.history > db.settings.historyLimit do
        table.remove(character.history, 1)
    end
end

local function SaveCharacter(moneyIsAuthoritative)
    local db = GetDB()
    local info = GetCharacterInfo()
    local old = db.characters[info.key] or {}

    if not info.spec or info.spec == "" or info.spec == "Unknown" then
        info.spec = old.spec or "Unknown"
    end

    if info.spec == "Unknown" and old.spec and old.spec ~= "" then
        info.spec = old.spec
    end

    if not info.itemLevel or info.itemLevel <= 0 then
        info.itemLevel = tonumber(old.itemLevel) or 0
    end

    if AreBagsLoaded() then
        bagsReady = true
    end

    if bagsReady then
        local newBags = SnapshotBags()

        if #newBags == 0 and old.bags and #old.bags > 0 then
            info.bags = old.bags
        else
            info.bags = newBags
        end
    else
        info.bags = old.bags or {}
    end

    local currentMoney = GetMoney()

    if moneyIsAuthoritative then
        info.money = currentMoney or 0
    elseif currentMoney and currentMoney > 0 then
        info.money = currentMoney
    else
        info.money = old.money or 0
    end

    info.bank = old.bank or {}
    info.bankUpdated = old.bankUpdated
    info.bankUpdatedTimestamp = old.bankUpdatedTimestamp
    info.firstSeen = old.firstSeen or date("%Y-%m-%d %H:%M:%S")
    info.totalPlayed = old.totalPlayed
    info.levelPlayed = old.levelPlayed
    info.history = old.history or {}

    db.characters[info.key] = info

    AddHistory(info, false)

    return info
end

local function SaveBank()
    if not bankOpen then
        return false
    end

    local snapshot, loaded = SnapshotBank()

    if not loaded then
        return false
    end

    local info = SaveCharacter(false)

    info.bank = snapshot
    info.bankUpdated = date("%Y-%m-%d %H:%M:%S")
    info.bankUpdatedTimestamp = time()

    GetDB().characters[info.key] = info

    return true
end

-- Обновление открытых окон хранилища после сохранения.
local function RefreshStorageWindows(key)
    if bagsWindow and bagsWindow:IsShown()
        and bagsWindow.characterKey == key then
        FillStorage(bagsWindow, key)
    end

    if bankWindow and bankWindow:IsShown()
        and bankWindow.characterKey == key then
        FillStorage(bankWindow, key)
    end
end

local function ScheduleCapture()
    if not C_Timer then
        if AreBagsLoaded() then
            bagsReady = true
        end

        SaveCharacter(false)
        return
    end

    local expectedKey = GetCharacterKey()

    -- Ранние проверки важны: сумки могут загрузиться
    -- вскоре после PLAYER_ENTERING_WORLD.
    local delays = {0.5, 1.5, 3, 6, 10, 15, 25, 40, 60}

    for _, delay in ipairs(delays) do
        C_Timer.After(delay, function()
            if GetCharacterKey() ~= expectedKey then
                return
            end

            if AreBagsLoaded() then
                bagsReady = true
            end

            local character = SaveCharacter(false)

            MCP:Refresh()

            if mainWindow and mainWindow:IsShown()
                and MCP.selectedCharacter == expectedKey then
                MCP:ShowDetails(expectedKey)
            end

            if character and bagsReady then
                RefreshStorageWindows(expectedKey)
            end
        end)
    end
end

-- Получаем специализацию повторно после загрузки персонажа.
local function ScheduleItemLevelCapture()
    if not C_Timer then return end

    local expectedKey = GetCharacterKey()
    local delays = {2, 5, 10, 20}

    for _, delay in ipairs(delays) do
        C_Timer.After(delay, function()
            if GetCharacterKey() ~= expectedKey then
                return
            end

            local itemLevel = GetEquippedItemLevel()
            if not itemLevel or itemLevel <= 0 then
                return
            end

            local character = GetDB().characters[expectedKey]
            if not character then
                character = SaveCharacter(false)
            end

            if character then
                character.itemLevel = itemLevel
                character.updated = date("%Y-%m-%d %H:%M:%S")
                character.updatedTimestamp = time()
                AddHistory(character, false)
                GetDB().characters[expectedKey] = character

                MCP:Refresh()
                if mainWindow and mainWindow:IsShown()
                    and MCP.selectedCharacter == expectedKey then
                    MCP:ShowDetails(expectedKey)
                end
            end
        end)
    end
end

local function ScheduleSpecializationCapture()
    if not C_Timer then return end

    local expectedKey = GetCharacterKey()
    local delays = {2, 5, 10}

    for _, delay in ipairs(delays) do
        C_Timer.After(delay, function()
            if GetCharacterKey() ~= expectedKey then
                return
            end

            local spec = GetSpecializationName()

            if not spec then
                return
            end

            local character = GetDB().characters[expectedKey]

            if not character then
                character = SaveCharacter(false)
            end

            if character then
                character.spec = spec
                character.updated = date("%Y-%m-%d %H:%M:%S")
                character.updatedTimestamp = time()

                AddHistory(character, false)

                GetDB().characters[expectedKey] = character

                MCP:Refresh()

                if mainWindow and mainWindow:IsShown()
                    and MCP.selectedCharacter == expectedKey then

                    MCP:ShowDetails(expectedKey)
                end
            end
        end)
    end
end

-- =========================================================
-- MAIN WINDOW
-- =========================================================

local function CreateMainWindow()
    if mainWindow then
        return mainWindow
    end

    local frame = CreateWindow(
        "MyCharPanelMainWindow",
        820, 620,
        "MY CHARACTER PANEL  |  AZEROTH GRIMOIRE"
    )

    frame.list = CreateFrame(
        "Frame", nil, frame, "BackdropTemplate"
    )

    frame.list:SetPoint("TOPLEFT", 18, -62)
    frame.list:SetSize(260, 530)

    CreateBackdrop(frame.list, PANEL, GOLD_DARK)
    AddInnerFrame(frame.list, 3, ARCANE)
    AddEdgeGlow(frame.list, 0.18)

    frame.details = CreateFrame(
        "Frame", nil, frame, "BackdropTemplate"
    )

    frame.details:SetPoint(
        "TOPLEFT", frame.list, "TOPRIGHT", 12, 0
    )

    frame.details:SetSize(510, 530)

    CreateBackdrop(frame.details, PANEL, GOLD_DARK)
    AddInnerFrame(frame.details, 3, ARCANE)
    AddEdgeGlow(frame.details, 0.18)

    local settingsButton = CreateButton(
        frame, "НАСТР.", 58, 24,
        function()
            MCP:ToggleSettings()
        end
    )

    settingsButton:SetPoint("TOPRIGHT", -47, -17)

    mainWindow = frame

    return frame
end

local function CreateCharacterRow(parent, character, index)
    local row = CreateFrame(
        "Button", nil, parent, "BackdropTemplate"
    )

    row:SetSize(240, 38)
    row:SetPoint(
        "TOPLEFT", 8, -8 - (index - 1) * 42
    )

    CreateBackdrop(row, DARK, GOLD_DARK)

    local r, g, b = GetClassColor(character.class)

    local classBar = row:CreateTexture(nil, "ARTWORK")

    classBar:SetTexture("Interface/Buttons/WHITE8X8")
    classBar:SetVertexColor(r, g, b, 0.95)
    classBar:SetPoint("TOPLEFT", 1, -1)
    classBar:SetPoint("BOTTOMLEFT", 1, 1)
    classBar:SetWidth(3)

    local classIcon = row:CreateTexture(nil, "ARTWORK")

    classIcon:SetSize(22, 22)
    classIcon:SetPoint("LEFT", 8, 0)

    SetClassIcon(classIcon, character.class)

    local name = CreateText(
        row,
        character.name or "Unknown",
        12,
        {r, g, b, 1}
    )

    name:SetPoint("LEFT", classIcon, "RIGHT", 6, 0)
    name:SetWidth(130)

    local level = CreateText(
        row,
        "Ур. " .. tostring(character.level or 1),
        10,
        GOLD_BRIGHT
    )

    level:SetPoint("RIGHT", -8, 0)

    row:SetScript("OnEnter", function(self)
        self:SetBackdropColor(
            PANEL_HOVER[1], PANEL_HOVER[2],
            PANEL_HOVER[3], 1
        )

        self:SetBackdropBorderColor(
            GOLD_BRIGHT[1], GOLD_BRIGHT[2],
            GOLD_BRIGHT[3], 1
        )
    end)

    row:SetScript("OnLeave", function(self)
        self:SetBackdropColor(
            DARK[1], DARK[2], DARK[3], DARK[4]
        )

        self:SetBackdropBorderColor(
            GOLD_DARK[1], GOLD_DARK[2],
            GOLD_DARK[3], GOLD_DARK[4]
        )
    end)

    if character.key == MCP.selectedCharacter then
        row:SetBackdropBorderColor(
            GOLD_BRIGHT[1], GOLD_BRIGHT[2],
            GOLD_BRIGHT[3], 1
        )
    end

    row:SetScript("OnClick", function()
        MCP.selectedCharacter = character.key

        MCP:ShowDetails(character.key)
        MCP:Refresh()
    end)

    return row
end

function MCP:Refresh()
    if not mainWindow then return end

    ClearFrame(mainWindow.list)

    local characters = {}
    local db = GetDB()

    for key, character in pairs(db.characters) do
        character.key = character.key or key
        characters[#characters + 1] = character
    end

    table.sort(characters, function(a, b)
        if a.key == GetCharacterKey() then return true end
        if b.key == GetCharacterKey() then return false end

        return (a.level or 0) > (b.level or 0)
    end)

    for index, character in ipairs(characters) do
        CreateCharacterRow(mainWindow.list, character, index)
    end

    if #characters == 0 then
        AddLine(
            mainWindow.list,
            "Персонажи пока не сохранены.",
            15,
            MUTED
        )
    end
end

-- =========================================================
-- CHARACTER DETAILS
-- =========================================================

function MCP:ShowDetails(key)
    if not mainWindow then return end

    local character = GetDB().characters[key]

    if not character then
        return
    end

    local parent = mainWindow.details

    ClearFrame(parent)

    local y = 15

    local function Line(value, color)
        AddLine(parent, value, y, color)
        y = y + 25
    end

    local function IconLine(icon, value, color)
        AddIconLine(parent, icon, value, y, color)
        y = y + 25
    end

    local r, g, b = GetClassColor(character.class)

    local classIcon = parent:CreateTexture(nil, "ARTWORK")

    classIcon:SetSize(26, 26)
    classIcon:SetPoint("TOPLEFT", 0, -y)

    SetClassIcon(classIcon, character.class)

    local characterTitle = CreateText(
        parent,
        (character.name or "?")
            .. " / "
            .. (character.realm or "?"),
        15,
        {r, g, b, 1}
    )

    characterTitle:SetPoint(
        "LEFT", classIcon, "RIGHT", 8, 0
    )

    y = y + 38

    AddArcaneDivider(parent, y - 8, 460)

    IconLine(
        136243,
        "Класс: " .. tostring(character.className or "?")
    )

    IconLine(
        134400,
        "Уровень: " .. tostring(character.level or 1)
    )

    IconLine(
        133784,
        "Раса: " .. tostring(character.race or "?")
    )

    IconLine(
        GetFactionIcon(character.faction),
        "Фракция: " .. GetLocalizedFaction(character.faction)
    )

    IconLine(
        132995,
        "Гильдия: "
            .. tostring(
                character.guild ~= "" and character.guild or "Нет"
            )
    )

    IconLine(
        135932,
        "Специализация: "
            .. tostring(character.spec or "Unknown")
    )

    IconLine(
        134939,
        "Уровень предметов: "
            .. tostring(math.floor(character.itemLevel or 0))
    )

    IconLine(
        133784,
        "Золото: " .. FormatMoney(character.money)
    )

    IconLine(
        132761,
        "Предметов в сумках: "
            .. tostring(#(character.bags or {}))
    )

    IconLine(
        133785,
        "Предметов в банке: "
            .. tostring(#(character.bank or {}))
    )

    IconLine(
        133743,
        "Банк обновлён: "
            .. tostring(character.bankUpdated or "Нет данных")
    )

    IconLine(
        132864,
        "Обновлён: "
            .. tostring(character.updated or "Нет данных")
    )

    IconLine(
        134376,
        "Всего наиграно: "
            .. FormatPlayedTime(character.totalPlayed or 0)
    )

    if sessionStart and sessionCharacterKey == key then
        IconLine(
            134376,
            "Текущий вход: "
                .. FormatPlayedTime(GetTime() - sessionStart),
            GOLD_BRIGHT
        )
    end

    y = y + 5

    Line("ПРОФЕССИИ", GOLD_BRIGHT)

    for _, profession in ipairs(character.professions or {}) do
        IconLine(
            profession.icon or 134400,
            tostring(profession.name or "Профессия")
                .. ": "
                .. tostring(profession.skill or 0)
                .. "/"
                .. tostring(profession.maxSkill or 0)
        )
    end

    y = y + 10

    local bags = CreateButton(
        parent, "СУМКИ", 88, 28,
        function()
            MCP:OpenBags(key)
        end
    )

    bags:SetPoint("TOPLEFT", 0, -y)

    local bank = CreateButton(
        parent, "БАНК", 88, 28,
        function()
            MCP:OpenBank(key)
        end
    )

    bank:SetPoint("LEFT", bags, "RIGHT", 8, 0)

    local history = CreateButton(
        parent, "ИСТОРИЯ", 88, 28,
        function()
            MCP:OpenHistory(key)
        end
    )

    history:SetPoint("LEFT", bank, "RIGHT", 8, 0)

    local delete = CreateButton(
        parent,
        "УДАЛИТЬ ИЗ СПИСКА",
        150,
        28,
        function()
            StaticPopupDialogs["MCP_DELETE"] = {
                text = "Убрать этого персонажа только из списка MyCharPanel? Персонаж в игре и его игровой прогресс не удаляются.",
                button1 = YES,
                button2 = NO,

                OnAccept = function()
                    GetDB().characters[key] = nil

                    MCP.selectedCharacter = nil

                    MCP:Refresh()
                    ClearFrame(parent)
                end,

                timeout = 0,
                whileDead = true,
                hideOnEscape = true,
            }

            StaticPopup_Show("MCP_DELETE")
        end
    )

    delete:SetPoint("LEFT", history, "RIGHT", 8, 0)
end

-- =========================================================
-- ACCOUNT STATISTICS
-- =========================================================

local function CalculateAccountStats()
    local stats = {
        characters = 0,
        totalGold = 0,
        totalPlayed = 0,
        highestLevel = 0,
        highestCharacter = "Нет данных",
        totalBags = 0,
        totalBank = 0,
        totalHistory = 0,
    }

    for _, character in pairs(GetDB().characters) do
        stats.characters = stats.characters + 1

        stats.totalGold = stats.totalGold
            + (tonumber(character.money) or 0)

        stats.totalPlayed = stats.totalPlayed
            + (tonumber(character.totalPlayed) or 0)

        stats.totalBags = stats.totalBags
            + #(character.bags or {})

        stats.totalBank = stats.totalBank
            + #(character.bank or {})

        stats.totalHistory = stats.totalHistory
            + #(character.history or {})

        if (character.level or 0) > stats.highestLevel then
            stats.highestLevel = character.level
            stats.highestCharacter = character.name or "Unknown"
        end
    end

    return stats
end

function MCP:OpenStats()
    if not GetDB().settings.showStats then
        Print("Статистика отключена в настройках.")
        return
    end

    if not statsWindow then
        statsWindow = CreateWindow(
            "MyCharPanelStatsWindow",
            500, 430,
            "ОБЩАЯ ЛЕТОПИСЬ АККАУНТА"
        )

        statsWindow.content = CreateFrame(
            "Frame", nil, statsWindow
        )

        statsWindow.content:SetPoint(
            "TOPLEFT", 25, -65
        )

        statsWindow.content:SetPoint(
            "BOTTOMRIGHT", -20, 20
        )
    end

    ClearFrame(statsWindow.content)

    local stats = CalculateAccountStats()
    local y = 5

    local function Line(icon, value, color)
        AddIconLine(
            statsWindow.content,
            icon,
            value,
            y,
            color or TEXT
        )

        y = y + 36
    end

    Line(
        132761,
        "Всего персонажей: " .. stats.characters,
        GOLD_BRIGHT
    )

    Line(
        133784,
        "Общее золото: " .. FormatMoney(stats.totalGold)
    )

    Line(
        134376,
        "Общее время игры: "
            .. FormatPlayedTime(stats.totalPlayed)
    )

    Line(
        134400,
        "Самый высокий уровень: " .. stats.highestLevel
    )

    Line(
        136243,
        "Персонаж: " .. stats.highestCharacter
    )

    Line(
        132761,
        "Предметов в сумках: " .. stats.totalBags
    )

    Line(
        133785,
        "Предметов в банках: " .. stats.totalBank
    )

    Line(
        134332,
        "Записей истории: " .. stats.totalHistory
    )

    statsWindow:Show()
    ApplyWindowSettings()
end

-- =========================================================
-- CHARACTER HISTORY
-- =========================================================

function MCP:OpenHistory(key)
    if not GetDB().settings.showHistory then
        Print("История отключена в настройках.")
        return
    end

    local character = GetDB().characters[key]

    if not character then
        return
    end

    if not historyWindow then
        historyWindow = CreateWindow(
            "MyCharPanelHistoryWindow",
            620, 500,
            "ЛЕТОПИСЬ ПЕРСОНАЖА"
        )

        local scroll = CreateFrame(
            "ScrollFrame",
            nil,
            historyWindow,
            "UIPanelScrollFrameTemplate"
        )

        scroll:SetPoint("TOPLEFT", 18, -62)
        scroll:SetPoint("BOTTOMRIGHT", -35, 18)

        local content = CreateFrame("Frame", nil, scroll)

        content:SetSize(550, 400)

        scroll:SetScrollChild(content)

        historyWindow.content = content
    end

    local content = historyWindow.content

    ClearFrame(content)

    local history = character.history or {}
    local y = 0

    local heading = CreateText(
        content,
        "Дата | Уровень | Золото | Уровень предметов | Специализация",
        10,
        GOLD_BRIGHT
    )

    heading:SetPoint("TOPLEFT", 4, 0)

    y = 28

    for index = #history, 1, -1 do
        local entry = history[index]

        local line = string.format(
            "%s | %s | %s | %s | %s",
            tostring(entry.date or "?"),
            tostring(entry.level or 1),
            FormatMoney(entry.money or 0),
            tostring(math.floor(entry.itemLevel or 0)),
            tostring(entry.spec or "?")
        )

        local fs = CreateText(content, line, 10, TEXT)

        fs:SetPoint("TOPLEFT", 4, -y)
        fs:SetWidth(540)

        y = y + 23
    end

    content:SetHeight(math.max(400, y + 20))

    historyWindow:Show()

    ApplyWindowSettings()
end

-- =========================================================
-- STORAGE WINDOWS: GRID AND LIST
-- =========================================================

local function GetStorageView(kind)
    local settings = GetDB().settings

    if kind == "bank" then
        return settings.bankView
    end

    return settings.bagsView
end

local function SetStorageView(kind, view)
    local settings = GetDB().settings

    if kind == "bank" then
        settings.bankView = view
    else
        settings.bagsView = view
    end
end

local function GetQualityColor(quality)
    quality = tonumber(quality) or 0

    if C_Item and C_Item.GetItemQualityColor then
        local r, g, b = C_Item.GetItemQualityColor(quality)

        if r then
            return r, g, b
        end
    end

    if GetItemQualityColor then
        local r, g, b = GetItemQualityColor(quality)

        if r then
            return r, g, b
        end
    end

    return GOLD[1], GOLD[2], GOLD[3]
end

local function ShowItemTooltip(button, item)
    if not item then return end

    GameTooltip:SetOwner(button, "ANCHOR_RIGHT")

    if item.id and GameTooltip.SetItemByID then
        GameTooltip:SetItemByID(item.id)

    elseif item.id then
        GameTooltip:SetHyperlink(
            "item:" .. tostring(item.id)
        )

    else
        GameTooltip:AddLine(item.name or "Предмет")
        GameTooltip:AddLine(
            "Нет данных о предмете",
            0.7, 0.7, 0.7
        )
    end

    GameTooltip:Show()
end

local function CreateGridItem(parent, item, index, columns)
    local size = 42
    local gap = 7

    local column = (index - 1) % columns
    local row = math.floor((index - 1) / columns)

    local button = CreateFrame(
        "Button", nil, parent, "BackdropTemplate"
    )

    button:SetSize(size, size)

    button:SetPoint(
        "TOPLEFT",
        5 + column * (size + gap),
        -(5 + row * (size + gap))
    )

    local r, g, b = GetQualityColor(item.quality)

    CreateBackdrop(button, PANEL_INNER, {r, g, b, 1})

    local icon = button:CreateTexture(nil, "ARTWORK")

    icon:SetPoint("TOPLEFT", 3, -3)
    icon:SetPoint("BOTTOMRIGHT", -3, 3)
    icon:SetTexture(item.icon or 134400)
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local count = CreateText(
        button,
        tostring(item.count or 1),
        10,
        {1, 0.9, 0.65, 1}
    )

    count:SetPoint("BOTTOMRIGHT", -3, 2)
    count:SetJustifyH("RIGHT")

    button:SetScript("OnEnter", function(self)
        ShowItemTooltip(self, item)
    end)

    button:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    button:SetScript("OnClick", function(self)
        ShowItemTooltip(self, item)
    end)

    return button
end

local function CreateListItem(parent, item, index)
    local row = CreateFrame(
        "Button", nil, parent, "BackdropTemplate"
    )

    row:SetSize(425, 26)

    row:SetPoint(
        "TOPLEFT", 5, -((index - 1) * 29)
    )

    local r, g, b = GetQualityColor(item.quality)

    CreateBackdrop(row, PANEL_INNER, {r, g, b, 1})

    local icon = row:CreateTexture(nil, "ARTWORK")

    icon:SetSize(20, 20)
    icon:SetPoint("LEFT", 4, 0)
    icon:SetTexture(item.icon or 134400)
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local name = CreateText(
        row,
        item.name or GetItemName(item.id),
        11,
        {r, g, b, 1}
    )

    name:SetPoint("LEFT", icon, "RIGHT", 7, 0)
    name:SetWidth(330)

    local count = CreateText(
        row,
        "x" .. tostring(item.count or 1),
        11,
        GOLD_BRIGHT
    )

    count:SetPoint("RIGHT", -8, 0)
    count:SetJustifyH("RIGHT")

    row:SetScript("OnEnter", function(self)
        self:SetBackdropColor(
            PANEL_HOVER[1], PANEL_HOVER[2],
            PANEL_HOVER[3], PANEL_HOVER[4]
        )

        ShowItemTooltip(self, item)
    end)

    row:SetScript("OnLeave", function(self)
        self:SetBackdropColor(
            PANEL_INNER[1], PANEL_INNER[2],
            PANEL_INNER[3], PANEL_INNER[4]
        )

        GameTooltip:Hide()
    end)

    row:SetScript("OnClick", function(self)
        ShowItemTooltip(self, item)
    end)

    return row
end

local function CreateStorageWindow(kind)
    local isBank = kind == "bank"

    local frame = CreateWindow(
        isBank and "MyCharPanelBankWindow"
            or "MyCharPanelBagsWindow",

        520,
        560,

        isBank and "АРХИВ БАНКА"
            or "АРХИВ СУМОК"
    )

    local who = CreateText(frame, "", 11, MUTED)

    who:SetPoint("TOPLEFT", 22, -58)

    frame.who = who

    frame.viewLabel = CreateText(
        frame, "ВИД:", 10, GOLD_BRIGHT
    )

    frame.viewLabel:SetPoint("TOPLEFT", 22, -78)

    frame.gridButton = CreateButton(
        frame, "СЕТКА", 75, 24,
        function()
            SetStorageView(kind, "grid")

            if frame.characterKey then
                FillStorage(frame, frame.characterKey)
            end
        end
    )

    frame.gridButton:SetPoint(
        "LEFT", frame.viewLabel, "RIGHT", 8, 0
    )

    frame.listButton = CreateButton(
        frame, "СПИСОК", 75, 24,
        function()
            SetStorageView(kind, "list")

            if frame.characterKey then
                FillStorage(frame, frame.characterKey)
            end
        end
    )

    frame.listButton:SetPoint(
        "LEFT", frame.gridButton, "RIGHT", 6, 0
    )

    local scroll = CreateFrame(
        "ScrollFrame",
        nil,
        frame,
        "UIPanelScrollFrameTemplate"
    )

    scroll:SetPoint("TOPLEFT", 18, -112)
    scroll:SetPoint("BOTTOMRIGHT", -35, 18)

    local content = CreateFrame("Frame", nil, scroll)

    content:SetSize(440, 40)

    scroll:SetScrollChild(content)

    frame.scroll = scroll
    frame.content = content
    frame.kind = kind

    return frame
end

FillStorage = function(frame, key)
    local character = GetDB().characters[key]

    if not character then
        return
    end

    frame.characterKey = key

    frame.who:SetText(
        (character.name or "?")
            .. " / "
            .. (character.realm or "?")
    )

    ClearFrame(frame.content)

    local items = frame.kind == "bank"
        and (character.bank or {})
        or (character.bags or {})

    local view = GetStorageView(frame.kind)
    local y = 0

    if #items == 0 then
        local empty = CreateText(
            frame.content,
            "Предметы ещё не сохранены.",
            12,
            MUTED
        )

        empty:SetPoint("TOPLEFT", 8, -8)

        frame.content:SetHeight(50)

    elseif view == "grid" then
        local columns = 9
        local size = 42
        local gap = 7

        for index, item in ipairs(items) do
            CreateGridItem(
                frame.content,
                item,
                index,
                columns
            )
        end

        local rows = math.ceil(#items / columns)

        y = 10 + rows * (size + gap)

        frame.content:SetHeight(math.max(440, y))

    else
        for index, item in ipairs(items) do
            CreateListItem(
                frame.content,
                item,
                index
            )
        end

        y = #items * 29 + 10

        frame.content:SetHeight(math.max(440, y))
    end

    frame.gridButton:SetBackdropBorderColor(
        GOLD_DARK[1], GOLD_DARK[2],
        GOLD_DARK[3], 1
    )

    frame.listButton:SetBackdropBorderColor(
        GOLD_DARK[1], GOLD_DARK[2],
        GOLD_DARK[3], 1
    )

    local active = view == "grid"
        and frame.gridButton
        or frame.listButton

    active:SetBackdropBorderColor(
        GOLD_BRIGHT[1], GOLD_BRIGHT[2],
        GOLD_BRIGHT[3], 1
    )

    frame:Show()

    ApplyWindowSettings()
end

function MCP:OpenBags(key)
    if not bagsWindow then
        bagsWindow = CreateStorageWindow("bags")
    end

    FillStorage(bagsWindow, key)
end

function MCP:OpenBank(key)
    if not bankWindow then
        bankWindow = CreateStorageWindow("bank")
    end

    FillStorage(bankWindow, key)
end

-- =========================================================
-- SETTINGS WINDOW
-- =========================================================

local function CreateSettings()
    local frame = CreateWindow(
        "MyCharPanelSettings",
        460, 570,
        "НАСТРОЙКИ ГРИМУАРА"
    )

    local settings = GetDB().settings

    -- FontStrings parented directly to the window can be drawn underneath
    -- child button/checkbutton frames on some WoW clients. Keep settings
    -- captions on a dedicated, non-interactive layer above the controls.
    local textLayer = CreateFrame("Frame", nil, frame)
    textLayer:SetAllPoints(frame)
    textLayer:SetFrameLevel(frame:GetFrameLevel() + 20)
    textLayer:EnableMouse(false)

    local info = CreateText(
        textLayer,
        "Изменения сохраняются автоматически.",
        11,
        MUTED
    )

    info:SetPoint("TOPLEFT", 24, -62)

    local themeTitle = CreateText(
        textLayer,
        "ТЕМА ОФОРМЛЕНИЯ",
        13,
        GOLD_BRIGHT
    )

    themeTitle:SetPoint("TOPLEFT", 25, -95)

    local darkTheme, lightTheme
    local UpdateThemeSelection

    darkTheme = CreateButton(
        frame,
        "ТЁМНЫЙ ПЕРГАМЕНТ",
        180,
        32,
        function()
            settings.theme = "dark"

            RefreshAllThemes()
            UpdateThemeSelection()
        end
    )

    darkTheme:SetPoint("TOPLEFT", 25, -120)

    lightTheme = CreateButton(
        frame,
        "СВЕТЛЫЙ ПЕРГАМЕНТ",
        180,
        32,
        function()
            settings.theme = "light"

            RefreshAllThemes()
            UpdateThemeSelection()
        end
    )

    lightTheme:SetPoint(
        "LEFT", darkTheme, "RIGHT", 10, 0
    )

    UpdateThemeSelection = function()
        local active = settings.theme == "light"
            and lightTheme
            or darkTheme

        local inactive = settings.theme == "light"
            and darkTheme
            or lightTheme

        active:SetBackdropBorderColor(
            GOLD_BRIGHT[1], GOLD_BRIGHT[2],
            GOLD_BRIGHT[3], 1
        )

        inactive:SetBackdropBorderColor(
            GOLD_DARK[1], GOLD_DARK[2],
            GOLD_DARK[3], 1
        )
    end

    UpdateThemeSelection()

    local function AddCheck(label, setting, y)
        local check = CreateFrame(
            "CheckButton",
            nil,
            frame,
            "UICheckButtonTemplate"
        )

        check:SetPoint(
            "TOPLEFT", 20, -180 - y
        )

        check:SetChecked(settings[setting])

        local text = CreateText(
            textLayer, label, 12, TEXT
        )

        text:SetPoint(
            "LEFT", check, "RIGHT", 4, 0
        )

        check:SetScript("OnClick", function(self)
            settings[setting] = self:GetChecked()
                and true
                or false

            if setting == "showMinimap" and minimapButton then
                minimapButton:SetShown(settings.showMinimap)
            end

            if setting == "showGlow" then
                ApplyGlowSettings()

            elseif setting == "showDecorations" then
                ApplyDecorationSettings()
            end
        end)

        return check
    end

    AddCheck("Кнопка на мини-карте", "showMinimap", 0)
    AddCheck("Сохранять историю персонажей", "showHistory", 30)
    AddCheck("Разрешить общую статистику", "showStats", 60)
    AddCheck("Золотые контуры окон", "showGlow", 90)
    AddCheck("Декоративные уголки", "showDecorations", 120)

    local scaleLabel = CreateText(
        textLayer, "", 12, GOLD_BRIGHT
    )

    scaleLabel:SetPoint("TOPLEFT", 25, -420)

    local function UpdateScaleLabel()
        scaleLabel:SetText(
            "Масштаб интерфейса: "
                .. math.floor(settings.scale * 100)
                .. "%"
        )
    end

    local scaleDown = CreateButton(
        frame, "-", 35, 26,
        function()
            settings.scale = math.max(
                0.75,
                settings.scale - 0.05
            )

            UpdateScaleLabel()
            ApplyWindowSettings()
        end
    )

    scaleDown:SetPoint("TOPLEFT", 25, -445)

    local scaleUp = CreateButton(
        frame, "+", 35, 26,
        function()
            settings.scale = math.min(
                1.25,
                settings.scale + 0.05
            )

            UpdateScaleLabel()
            ApplyWindowSettings()
        end
    )

    scaleUp:SetPoint(
        "LEFT", scaleDown, "RIGHT", 8, 0
    )

    UpdateScaleLabel()

    local reset = CreateButton(
        frame,
        "СБРОСИТЬ",
        130,
        30,
        function()
            settings.showMinimap = true
            settings.showHistory = true
            settings.showStats = true
            settings.showGlow = true
            settings.showDecorations = true

            settings.opacity = nil
            settings.scale = 1
            settings.theme = "dark"

            settings.bagsView = "grid"
            settings.bankView = "grid"

            RefreshAllThemes()

            UpdateThemeSelection()
            UpdateScaleLabel()

            ApplyWindowSettings()
            ApplyGlowSettings()
            ApplyDecorationSettings()

            if minimapButton then
                minimapButton:SetShown(true)
            end

            Print("Настройки сброшены.")
        end
    )

    reset:SetPoint("BOTTOMLEFT", 24, 18)

    local refresh = CreateButton(
        frame,
        "ОБНОВИТЬ ДАННЫЕ",
        180,
        30,
        function()
            SaveCharacter(false)

            ScheduleCapture()
            ScheduleSpecializationCapture()
            ScheduleItemLevelCapture()

            MCP:Refresh()

            Print("Данные обновлены.")
        end
    )

    refresh:SetPoint("BOTTOMRIGHT", -24, 18)

    return frame
end

function MCP:ToggleSettings()
    if not settingsWindow then
        settingsWindow = CreateSettings()
    end

    if settingsWindow:IsShown() then
        settingsWindow:Hide()
    else
        settingsWindow:Show()
        ApplyWindowSettings()
    end
end

-- =========================================================
-- MAIN TOGGLE
-- =========================================================

function MCP:ToggleMain()
    if not mainWindow then
        CreateMainWindow()
    end

    if mainWindow:IsShown() then
        mainWindow:Hide()
        return
    end

    SaveCharacter(false)

    self.selectedCharacter = self.selectedCharacter
        or GetCharacterKey()

    if not GetDB().characters[self.selectedCharacter] then
        self.selectedCharacter = GetCharacterKey()
    end

    self:Refresh()
    self:ShowDetails(self.selectedCharacter)

    mainWindow:Show()

    ApplyWindowSettings()
end

-- =========================================================
-- MINIMAP BUTTON
-- =========================================================

local function CreateMinimapButton()
    if minimapButton or not Minimap then
        return
    end

    local button = CreateFrame(
        "Button",
        "MyCharPanelMinimapButton",
        Minimap
    )

    button:SetSize(32, 32)

    button:SetPoint(
        "TOPRIGHT", Minimap, "TOPRIGHT", -2, -2
    )

    local icon = button:CreateTexture(nil, "ARTWORK")

    icon:SetTexture("Interface/Icons/INV_Misc_Book_09")
    icon:SetAllPoints()

    local border = button:CreateTexture(nil, "OVERLAY")

    border:SetTexture("Interface/Buttons/WHITE8X8")

    border:SetPoint("TOPLEFT", -2, 2)
    border:SetPoint("BOTTOMRIGHT", 2, -2)

    border:SetVertexColor(
        GOLD_BRIGHT[1], GOLD_BRIGHT[2],
        GOLD_BRIGHT[3], 0.75
    )

    AddEdgeGlow(button, 0.25)

    button:SetScript("OnClick", function()
        MCP:ToggleMain()
    end)

    button:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")

        GameTooltip:AddLine(
            "MyCharPanel Epic " .. VERSION,
            1, 0.78, 0.35
        )

        GameTooltip:AddLine("/mcp", 0.9, 0.85, 0.7)

        GameTooltip:AddLine(
            "Нажми, чтобы открыть панель",
            0.7, 0.7, 0.7
        )

        GameTooltip:Show()
    end)

    button:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    minimapButton = button

    button:SetShown(GetDB().settings.showMinimap)
end

-- =========================================================
-- EVENTS
-- =========================================================

local function OnAddonLoaded()
    GetDB()

    SaveCharacter(false)

    CreateMainWindow()
    CreateMinimapButton()

    ApplyWindowSettings()
    ApplyGlowSettings()
    ApplyDecorationSettings()

    Print("Epic " .. VERSION .. " загружен.")

    Print(
        "Тема: "
            .. (
                GetDB().settings.theme == "dark"
                and "тёмный пергамент"
                or "светлый пергамент"
            )
    )

    Print(
        "Команды: /mcp, /mcp settings, /mcp stats, /mcp history"
    )
end

MCP:RegisterEvent("ADDON_LOADED")
MCP:RegisterEvent("PLAYER_ENTERING_WORLD")
MCP:RegisterEvent("PLAYER_LOGOUT")
MCP:RegisterEvent("PLAYER_MONEY")
MCP:RegisterEvent("BAG_UPDATE_DELAYED")
MCP:RegisterEvent("BAG_UPDATE")
MCP:RegisterEvent("BANKFRAME_OPENED")
MCP:RegisterEvent("BANKFRAME_CLOSED")
MCP:RegisterEvent("PLAYER_LEVEL_UP")
MCP:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
MCP:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
MCP:RegisterEvent("PLAYER_AVG_ITEM_LEVEL_UPDATE")
MCP:RegisterEvent("TIME_PLAYED_MSG")
MCP:RegisterEvent("PLAYER_GUILD_UPDATE")

MCP:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local addon = ...

        if addon == ADDON_NAME then
            OnAddonLoaded()
        end

    elseif event == "PLAYER_ENTERING_WORLD" then
        bagsReady = false

        sessionStart = GetTime()
        sessionCharacterKey = GetCharacterKey()
        pendingTimePlayed = true

        SaveCharacter(false)

        ScheduleCapture()
        ScheduleSpecializationCapture()
        ScheduleItemLevelCapture()

        if RequestTimePlayed then
            pcall(RequestTimePlayed)
        end

    elseif event == "PLAYER_MONEY" then
        SaveCharacter(true)

        if RequestTimePlayed then
            pcall(RequestTimePlayed)
        end

        MCP:Refresh()

    elseif event == "TIME_PLAYED_MSG" then
        local totalTime, levelTime = ...

        if pendingTimePlayed then
            pendingTimePlayed = false

            local key = GetCharacterKey()
            local character = GetDB().characters[key]

            if character then
                character.totalPlayed = totalTime
                character.levelPlayed = levelTime

                GetDB().characters[key] = character
            end

            MCP:Refresh()

            if mainWindow and mainWindow:IsShown() then
                MCP:ShowDetails(key)
            end
        end

    elseif event == "PLAYER_LOGOUT" then
        if bankOpen then
            SaveBank()
        end

        SaveCharacter(false)

    elseif event == "BAG_UPDATE"
        or event == "BAG_UPDATE_DELAYED" then

        local expectedKey = GetCharacterKey()

        local function UpdateBags()
            if GetCharacterKey() ~= expectedKey then
                return
            end

            if AreBagsLoaded() then
                bagsReady = true
            end

            SaveCharacter(false)

            if bankOpen then
                SaveBank()
            end

            MCP:Refresh()

            if mainWindow and mainWindow:IsShown()
                and MCP.selectedCharacter == expectedKey then

                MCP:ShowDetails(expectedKey)
            end

            RefreshStorageWindows(expectedKey)
        end

        if C_Timer then
            C_Timer.After(0.35, UpdateBags)
        else
            UpdateBags()
        end

    elseif event == "BANKFRAME_OPENED" then
        bankOpen = true

        if C_Timer then
            C_Timer.After(1, function()
                if bankOpen then
                    SaveBank()
                    RefreshStorageWindows(GetCharacterKey())
                end
            end)
        end

    elseif event == "BANKFRAME_CLOSED" then
        if bankOpen then
            SaveBank()
        end

        bankOpen = false

    elseif event == "PLAYER_LEVEL_UP"
        or event == "PLAYER_SPECIALIZATION_CHANGED"
        or event == "PLAYER_EQUIPMENT_CHANGED"
        or event == "PLAYER_AVG_ITEM_LEVEL_UPDATE"
        or event == "PLAYER_GUILD_UPDATE" then

        SaveCharacter(false)

        if event == "PLAYER_SPECIALIZATION_CHANGED" then
            ScheduleSpecializationCapture()
        end

        if event == "PLAYER_EQUIPMENT_CHANGED"
            or event == "PLAYER_AVG_ITEM_LEVEL_UPDATE" then
            ScheduleItemLevelCapture()
        end

        MCP:Refresh()

        if mainWindow and mainWindow:IsShown()
            and MCP.selectedCharacter == GetCharacterKey() then

            MCP:ShowDetails(GetCharacterKey())
        end
    end
end)

-- =========================================================
-- SLASH COMMANDS
-- =========================================================

SLASH_MYCHARPANEL1 = "/mcp"

SlashCmdList["MYCHARPANEL"] = function(message)
    message = strtrim(message or ""):lower()

    if message == "stats" then
        MCP:OpenStats()

    elseif message == "history" then
        MCP:OpenHistory(GetCharacterKey())

    elseif message == "settings"
        or message == "options" then

        MCP:ToggleSettings()

    elseif message == "refresh" then
        SaveCharacter(false)
        ScheduleCapture()
        ScheduleSpecializationCapture()
        ScheduleItemLevelCapture()

        MCP:Refresh()

        Print("Данные обновлены.")

    else
        MCP:ToggleMain()
    end
end
